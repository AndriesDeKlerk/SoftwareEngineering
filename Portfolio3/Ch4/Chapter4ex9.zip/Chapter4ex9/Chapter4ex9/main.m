//
//  main.m
//  Chapter4ex9
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Calculator.h"

int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        //Calculator *deskCalc = [[Calculator alloc]init];
        Calculator *deskCalc = [Calculator new];
        
        [deskCalc setAccumulator: 100.0];
        NSLog (@"The result is %g", [deskCalc accumulator]);
        
        [deskCalc add: 200];
        NSLog (@"The result is %g", [deskCalc accumulator]);
        
        [deskCalc divide: 15];
        NSLog (@"The result is %g", [deskCalc accumulator]);
        
        [deskCalc subtract: 10.0];
        NSLog (@"The result is %g", [deskCalc accumulator]);
        
        [deskCalc multiply: 5];
        NSLog (@"The result is %g", [deskCalc accumulator]);
        
        [deskCalc changeSign];
        NSLog (@"Using changeSign method: %g", [deskCalc accumulator]);
        
        [deskCalc reciprocal];
        NSLog (@"Using reciprocal method: %g", [deskCalc accumulator]);
        
        [deskCalc xSquared];
        NSLog (@"Using the xSquared method: %g", [deskCalc accumulator]);
        
    }
    return 0;
}
