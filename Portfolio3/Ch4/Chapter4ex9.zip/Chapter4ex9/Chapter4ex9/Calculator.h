//
//  Calculator.h
//  Chapter4ex9
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Calculator : NSObject

-(void) setAccumulator: (double) value;
-(void) clear;
-(double) accumulator;

-(double) add: (double) value;
-(double) subtract: (double) value;
-(double) multiply: (double) value;
-(double) divide: (double) value;
-(double) changeSign; // change sign of accumulator
-(double) reciprocal; // 1/accumulator
-(double)xSquared; //accumulator squared

@end

@implementation Calculator
{
    double accumulator;
}

-(void) setAccumulator: (double) value{
    accumulator = value;
}

-(void) clear{
    accumulator = 0;
}

-(double) accumulator{
    return accumulator;
}

-(double) add: (double) value{
    
    accumulator += value;
    return accumulator;
}

-(double) subtract: (double) value{
    accumulator -=value;
    return accumulator;
}

-(double) multiply: (double) value{
    accumulator *= value;
    return accumulator;
}

-(double) divide: (double) value{
    accumulator /= value;
    return accumulator;
}

-(double)changeSign{ //Take the accumulator value and change the sign
    accumulator = - accumulator;
    return accumulator;
}

-(double)reciprocal{ // take the current value of the accumulator and do its reciprocal
    accumulator = 1 / accumulator;
    return accumulator;
}

-(double)xSquared{ // take the value of the accumulator at the currnt time and detirmine its square
    accumulator = accumulator * accumulator;
    return  accumulator;
}

@end


