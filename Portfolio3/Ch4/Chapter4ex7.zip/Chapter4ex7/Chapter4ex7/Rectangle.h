//
//  Rectangle.h
//  Chapter4ex7
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface Rectangle: NSObject
-(void) setWidth: (int) w;
-(void) setHeight: (int) h;
-(int) width;
-(int) height;
-(int) area;
-(int) preimeter;
@end

@implementation Rectangle
{
    int width;
    int height;
    int area;
    int preimeter;
}

-(int) height
{
    return height;
}

-(int) width
{
    return width;
}

-(void) setWidth:(int)w
{
    width = w;
}

-(void) setHeight:(int)h
{
    height = h;
}

-(int) area {
    return width * height;
}

-(int) preimeter {
    return (width + height) * 2;
}
@end

