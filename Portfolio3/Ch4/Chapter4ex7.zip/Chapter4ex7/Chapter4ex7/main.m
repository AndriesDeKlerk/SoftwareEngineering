//
//  main.m
//  Chapter4ex7
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Rectangle.h"
int main(int argc, char *argv[]) {
    @autoreleasepool {
        Rectangle *myRectangle = [[Rectangle alloc]init];
        [myRectangle setWidth: 2];
        [myRectangle setHeight: 3];
        NSLog(@"area = %d, preimeter = %d",[myRectangle area] ,[myRectangle preimeter]);
    }
    return 0;
}