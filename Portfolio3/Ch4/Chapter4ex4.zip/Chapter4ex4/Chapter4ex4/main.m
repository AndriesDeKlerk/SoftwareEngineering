//
//  main.m
//  Chapter4ex4
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        double result = 0.0;
        double x = 2.55;
        result = 3 * (x * x * x) - 5 * (x * x) + 6;
        printf ("3x^3 - 5x^2 + 6 = %f\n", result);
    }
    return 0;
}
