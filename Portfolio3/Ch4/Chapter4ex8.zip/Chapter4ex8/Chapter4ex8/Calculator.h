//
//  Calculator.h
//  Chapter4ex8
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Calculator : NSObject

-(void) SetAccumulator: (double) value;
-(void) clear;
-(double) accumulator;

-(double) add: (double) value;      //changed -(void) to -(double)
-(double) subtract: (double) value; //changed -(void) to -(double)
-(double) multiply: (double) value; //changed -(void) to -(double)
-(double) divide: (double) value;   //changed -(void) to -(double)

@end

@implementation Calculator
{
    double accumulator;
}

-(void) SetAccumulator: (double) value{
    accumulator = value;
}

-(void) clear{
    accumulator = 0;
}

-(double) accumulator{
    return accumulator;
}

-(double) add: (double) value{ //changed -(void) to -(double)
    
    accumulator += value;
    return accumulator;         //added return accumulator statement
}

-(double) subtract: (double) value{ //changed -(void) to -(double)
    accumulator -=value;
    return accumulator;         //added return accumulator statement
}

-(double) multiply: (double) value{ //changed -(void) to -(double)
    accumulator *= value;
    return accumulator;         //added return accumulator statement
}

-(double) divide: (double) value{ //changed -(void) to -(double)
    accumulator /= value;
    return accumulator;         //added return accumulator statement
}

@end


