//
//  main.m
//  Chapter4ex5
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    
    float float1 = (3.31e-8 + 2.01e-7);
    float float2 = (7.16e-6 + 2.01e-8);
    
    @autoreleasepool {
        NSLog(@"The value of this equation 3.31 x 10^-8 + 2.01 x 10^-7) / (7.16 x 10^-6 + 2.01 x 10^-8 is %f", float1 / float2);
    }
    return 0;
}
