//
//  main.m
//  Chapter4ex2
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        double celsius;
        double fahrenheit = 27;
        celsius = (fahrenheit - 32) / 1.8;
        NSLog (@"The temperature in degrees celsius is %f", celsius);
    }
    return 0;
}
