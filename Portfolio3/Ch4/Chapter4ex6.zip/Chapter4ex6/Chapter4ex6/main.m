//
//  main.m
//  Chapter4ex6
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Complex.h"

int main (int argc, char *argv[])
{
    @autoreleasepool {
        
        Complex *myComplex=[[Complex alloc] init];
        
        [myComplex setReal:3];
        [myComplex setImaginary:4];
        [myComplex print];
    }
    return 0;
}

