//
//  Complex.h
//  Chapter4ex6
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface Complex: NSObject
{
    double real, imaginary;
}
-(void)setReal: (double) a;
-(void)setImaginary: (double) b;
-(void) print;
-(double) real;
-(double) imaginary;
@end

@implementation Complex

-(void)setReal: (double) a
{
    real =a;
}

-(void)setImaginary: (double) b
{
    imaginary = b;
}
-(void) print
{
    NSLog(@"Your number is %.2f+%.2fi", real, imaginary);
}
-(double)real
{
    return real;
}

-(double)imaginary
{
    return imaginary;
}
@end
