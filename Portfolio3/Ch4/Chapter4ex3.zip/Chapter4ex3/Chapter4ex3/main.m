//
//  main.m
//  Chapter4ex3
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>
int main (int argc, char * argv[])
{
    @autoreleasepool {
        char c, d;
        
        c = 'd';
        d = c;
        NSLog (@"d = %c", d);
    }
    return 0;
}

