//
//  main.m
//  Chapter5ex4
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        int n, j;
        long factorial=1;
        for (n=0; n<20; n++)
        {
            for (j=1; j<=n; j++)
            {
                factorial *=j;
            }
            NSLog(@"Factor of %-3i is %18li", n, factorial);
            factorial=1;
        }
    }
    return 0;
}
