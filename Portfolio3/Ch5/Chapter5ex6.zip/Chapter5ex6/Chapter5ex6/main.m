//
//  main.m
//  Chapter5ex6
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>
int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        
        /* -------- 5.2 for statement
         
         int n = 0, triangularNumber;
         
         triangularNumber = 0;
         
         for ( n = 1; n <= 200; n = n + 1 ){
         triangularNumber += n;
         n++;
         }
         
         NSLog(@"The 200th triangular number is: %i", triangularNumber);
         
         */
        

        
        
        /* -------- 5.2 while statement
         
         int n = 0, triangularNumber;
         
         triangularNumber = 0;
         
         while (n <= 200){
         triangularNumber += n;
         n++;
         }
         
         NSLog(@"The 200th triangular number is: %i", triangularNumber);
         
         */
        
        /*---------------------------------------------------------------------------------------*/
        
        /* ------------ 5.3 for statement
         
         int n = 0 , triangularNumber;
         
         NSLog(@"Table OF TRIANGULAR NUMBERS");
         NSLog(@"n   Sum from 1 to n");
         NSLog(@"--  ---------------");
         
         triangularNumber = 0;
         
         for ( n = 1; n <= 10; ++n ) {
         triangularNumber += n;
         NSLog(@"%i    %i",n, triangularNumber);
         n++;
         }
         */

        
        /* ------------ 5.3 while statement
         
         int n = 0 , triangularNumber;
         
         NSLog(@"Table OF TRIANGULAR NUMBERS");
         NSLog(@"n   Sum from 1 to n");
         NSLog(@"--  ---------------");
         
         triangularNumber = 0;
         
         while (n <= 10) {
         triangularNumber += n;
         NSLog(@"%i    %i",n, triangularNumber);
         n++;
         }
         */
        
        /*---------------------------------------------------------------------------------------*/
        
        /* ---------------- 5.3A for statement
         
         int n = 0 , triangularNumber;
         
         NSLog(@"Table OF TRIANGULAR NUMBERS");
         NSLog(@"n   Sum from 1 to n");
         NSLog(@"--  ---------------");
         
         triangularNumber = 0;
         
         for ( n = 1; n <= 10; ++n ) {
         triangularNumber += n;
         NSLog(@"%2i    %i",n, triangularNumber);
         n++;
         }
         */
        
        /* ---------------- 5.3A while statement
         
         int n = 0 , triangularNumber;
         
         NSLog(@"Table OF TRIANGULAR NUMBERS");
         NSLog(@"n   Sum from 1 to n");
         NSLog(@"--  ---------------");
         
         triangularNumber = 0;
         
         while (n <= 10) {
         triangularNumber += n;
         NSLog(@"%2i    %i",n, triangularNumber);
         n++;
         }
         */

        /*---------------------------------------------------------------------------------------*/
        
        /* ------------- 5.4 for statement
         
         int n = 1, number, triangularNumber;
         
         NSLog(@"What triangular number do you want?");
         scanf("%i", &number);
         
         triangularNumber = 0;
         
         for ( n = 1; n <= number; ++n ) {
         triangularNumber += n;
         n++;
         }
         
         NSLog(@"Triangular number %i is %i\n", number, triangularNumber);
         */
        
        /* ------------- 5.4 while statement
         
         int n = 1, number, triangularNumber;
         
         NSLog(@"What triangular number do you want?");
         scanf("%i", &number);
         
         triangularNumber = 0;
         
         while (n <= number) {
         triangularNumber += n;
         n++;
         }
         
         NSLog(@"Triangular number %i is %i\n", number, triangularNumber);
         */
        
        /*---------------------------------------------------------------------------------------*/
        
        /* -------------- 5.5 for statement
         
         int n, number, triangularNumber, counter;
         
         for ( counter = 1; counter <= 5; ++counter ){
         NSLog(@"What triangular number do you want?\n");
         scanf("%i", &number);
             
             triangularNumber = 0;
         
         for ( n = 1; n <= number; ++n ){
         triangularNumber += n;
         }
         NSLog(@"Triangular number %i is %i\n", number, triangularNumber);
         }
         
        */
        
        /* -------------- 5.5 while statement
         
         int n, number, triangularNumber, counter;
         
         while (counter <= 5){
         NSLog(@"What triangular number do you want?\n");
         scanf("%i", &number);
             ++counter;
        
         while ( n <= number){
         triangularNumber += n;
             ++n;
         }

         NSLog(@"Triangular number %i is %i\n", number, triangularNumber);
         }
         
         */
    }
    return 0;
}
