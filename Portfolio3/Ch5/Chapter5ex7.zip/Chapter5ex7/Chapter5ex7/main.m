//
//  main.m
//  Chapter5ex7
//
//  Created by AJ IT GUY on 21/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
         int u;
         int v;
         int temp;
        
        
        NSLog(@"Enter two numbers: ");
        scanf("%u%u", &u , &v);
        
        while (v != 0)
        {
            temp = u % v;
            u = v;
            v = temp;
        }
        
        
        NSLog(@" Greatest Common Factor: %u" , u);
    }
    return 0;
}

