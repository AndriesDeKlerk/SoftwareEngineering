//
//  main.m
//  Chapter5ex3
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        
        int num, factoral = 1;
        
        NSLog(@"TABLE OF FACTORIAL NUMBERS");
        NSLog(@" Number       Factorial");
        NSLog(@"--------------------------");
        
        for (num = 1; num <= 10; ++num)
        {
            factoral *= num;
            NSLog(@" %2i            %7i", num, factoral);
        }
        
    }
    return 0;
}