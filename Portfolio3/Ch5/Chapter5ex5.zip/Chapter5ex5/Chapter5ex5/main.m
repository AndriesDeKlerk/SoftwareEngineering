//
//  main.m
//  Chapter5ex5
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        int n, number, triangularNumber, counter;
        
        NSLog(@"How triangular numbers would you like to calculate");
        scanf ("%i", &number);
        NSLog(@"You have selected %i", number);
        
        for (counter = 1; counter <= number; ++counter) { // counter does not need to be initialized, as it is provided by the user
            NSLog(@"What triangular number do you want?");
            scanf ("%i", &number);
            
            triangularNumber = 0;
            
            for (n = 1; n <= number; ++n)
                triangularNumber += n;
                
                NSLog(@"Triangular number %i is %i", number, triangularNumber);
        }
    }
    return 0;
    
}
