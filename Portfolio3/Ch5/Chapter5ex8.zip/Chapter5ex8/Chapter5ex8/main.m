//
//  main.m
//  Chapter5ex8
//
//  Created by AJ IT GUY on 21/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        int number, digits, sum;
        
        NSLog(@"Enter your number.");
        scanf("%d", &number);

        while (number != 0)
        {
            digits = number % 10;
            sum += digits;
            number /= 10;
        }
        NSLog(@"the sum of all digits is %d", sum);
    }
    return 0;
    
}
