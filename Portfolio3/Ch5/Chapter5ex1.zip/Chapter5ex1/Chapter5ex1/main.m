//
//  main.m
//  Chapter5ex1
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        int n, n2;
        NSLog(@"  n       n^2");
        NSLog(@" --      ----");
        
        n2 = 0;
        
        for ( n = 1; n <= 10; n +=1)
        {
            n2 = n * n;
            NSLog (@" %2i       %3i", n, n2);
        }
        
    }
    return 0;
}
