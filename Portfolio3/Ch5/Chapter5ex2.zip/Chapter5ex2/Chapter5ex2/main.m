//
//  main.m
//  Chapter5ex2
//
//  Created by AJ IT GUY on 20/09/2015.
//  Copyright (c) 2015 AJ IT GUY. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        int triangularNumber, n;
        
        n = 0;
        
        for (n = 5; n <= 50; n = n + 5) {
            
            triangularNumber = n  * ( n + 1) / 2;
            
            NSLog(@"The triangular number of %i is %i",n, triangularNumber);
        }
    }
    return 0;
}